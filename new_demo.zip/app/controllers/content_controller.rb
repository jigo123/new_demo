class ContentController < ApplicationController
  
end
