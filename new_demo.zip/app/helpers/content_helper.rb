module ContentHelper
end
