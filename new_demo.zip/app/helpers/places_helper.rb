module PlacesHelper
end
