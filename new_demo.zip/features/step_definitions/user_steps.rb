Given /^I have the test user$/ do
  @user = Factory(:user)
end
