require 'spec_helper'

describe "api/index.html.haml" do
end
