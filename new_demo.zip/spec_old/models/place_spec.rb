require 'spec_helper'

describe Place do
end
