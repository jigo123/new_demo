require 'spec_helper'

describe RegistrationsController do

end
