require 'spec_helper'

describe PlacesController do

end
