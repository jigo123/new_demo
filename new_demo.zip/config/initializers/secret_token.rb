# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Tap::Application.config.secret_token = '5fc781889fa3bd6d391e970d7e3fe08c49f650711cef639a5d3d13fb2cd6311f5f0b0d1002b30d489f641cfd1b2a720720b06efe275948185fe3a260678f40bd'
